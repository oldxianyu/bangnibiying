<p align="center">
<a href="http://bing.jsfinder.cn/" target="_blank">
<img src="https://xqimg.imedao.com/17356a573dac56a3fcbaa935.png" alt="让我帮你必应一下">
</a>
</p>

<h3 align="center"> 「Bing| Ask and it is given」</h3>

让我帮你必应一下 - 优化版

原始版本来自 http://tool.mkblog.cn/lmbtfy/，本人在原作的基础上进行了重制，风格变更为新版必应 UI，并适配了移动端

交互效果参考了 不会必应么？( https://cn.bing.com/ )

### 在线演示
-----

[http://bing.jsfinder.cn/](http://bing.jsfinder.cn/)


### 相关项目
-----

- Let Me Baidu That For You https://github.com/mengkunsoft/lmbtfy
